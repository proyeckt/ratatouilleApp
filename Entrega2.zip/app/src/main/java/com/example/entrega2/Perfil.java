package com.example.entrega2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

public class Perfil extends AppCompatActivity {

    Button btnCerrar,btnAnia;
    FirebaseAuth mAuth;
    DatabaseReference myRef;
    FirebaseDatabase database;
    TextView txtnombre,txtedad,txtdire,txtUte;
    ImageView img;
    EditText campo;
    public static ArrayList<String> arregloUtensilios;
    public static final String PATH_CLIENTS="clients/";
    public static final String PATH_CHEFS="chefs/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        arregloUtensilios = new ArrayList<>();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
        btnAnia=findViewById(R.id.btnAnia);
        mAuth = FirebaseAuth.getInstance();
        btnCerrar= findViewById(R.id.btnCerrar);
        database = FirebaseDatabase.getInstance();
        txtnombre = findViewById(R.id.txtNombre);
        txtedad = findViewById(R.id.txtedad);
        txtdire= findViewById(R.id.txtdire);
        img= findViewById(R.id.imageView);
        campo =  findViewById(R.id.editTextUten);
        txtUte = findViewById(R.id.textView4);

        refrescarPantalla();


        btnCerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent = new Intent(Perfil.this, AuthActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        btnAnia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s= campo.getText().toString();
                arregloUtensilios.add(s);
                String t = crearListado(arregloUtensilios);
                txtUte.setText(t);
            }
        });
    }

    private void refrescarPantalla() {
        if(this.getIntent().getStringExtra("tipo")=="U"){
            myRef = database.getReference(PATH_CLIENTS);
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    //DataSnapshot singleSnapshot = myRef.child(mAuth.getUid());
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        System.out.println("no entra al if");
                        if(mAuth.getUid()==singleSnapshot.getKey()) {
                            Cliente cliente = singleSnapshot.getValue(Cliente.class);
                            Log.i("TAG", "Encontró usuario: " + cliente.getNombre());
                            String name = cliente.getNombre() + " " + cliente.getApellido();
                            String age = String.valueOf(cliente.getEdad());

                            String lugar = cliente.getDireccion().getDir();
                            txtnombre.setText(name);
                            txtedad.setText(age);
                            txtdire.setText(lugar);
                            String urlF = cliente.getFoto();
                            Uri url = Uri.parse(urlF);
                            final InputStream imageStream;
                            try {
                                imageStream = getContentResolver().openInputStream(url);
                                System.out.println("uri de imagen"+url.toString());
                                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                                img.setImageBitmap(selectedImage);
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }
                            arregloUtensilios = cliente.getUtensilios();

                            //Toast.makeText(Perfil.this, name + ":" + age, Toast.LENGTH_SHORT).show();

                        }
                    } }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.w("TAG", "error en la consulta", databaseError.toException()); }
            });
        }

        else if(this.getIntent().getStringExtra("tipo")=="C"){
            myRef = database.getReference(PATH_CHEFS);
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        //System.out.println("no entra al if");
                        System.out.println("llave user : "+mAuth.getUid());
                        System.out.println("llave buscada: "+singleSnapshot.getKey());
                        if(mAuth.getUid().equals(singleSnapshot.getKey())) {
                            System.out.println("entree");
                            Chef chef = singleSnapshot.getValue(Chef.class);
                            Log.i("TAG", "Encontró usuario: " + chef.getNombre());
                            String name = chef.getNombre() + " " + chef.getApellido();
                            String age = String.valueOf(chef.getEdad());
                            String lugar = chef.getDireccion().getDir();
                            txtnombre.setText(name);
                            txtedad.setText(age);
                            txtdire.setText(lugar);
                            String urlF = chef.getFoto();
                            Uri url = Uri.parse(urlF);
                            final InputStream imageStream;
                            try {
                                imageStream = getContentResolver().openInputStream(url);
                                System.out.println("uri de imagen"+url.toString());
                                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                                img.setImageBitmap(selectedImage);
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }
                            arregloUtensilios = chef.getUtensilios();
                            //Toast.makeText(this,"uri de imagen"+url.toString(),Toast.LENGTH_LONG).show();




                            //Toast.makeText(Perfil.this, name + ":" + age, Toast.LENGTH_SHORT).show();
                        }
                    } }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.w("TAG", "error en la consulta", databaseError.toException()); }
            });
        }



    }
    public String crearListado(ArrayList<String> arreglo){
        String s= new String();
        for (String a: arreglo ){
            s=s+a+"\n";

        }
        return s;

    }
}

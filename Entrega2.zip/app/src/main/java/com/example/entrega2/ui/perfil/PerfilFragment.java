package com.example.entrega2.ui.perfil;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;

import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;
import com.example.entrega2.GlideApp;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
//import com.app.path.where.the.myappglidemodule.is.GlideApp;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.bumptech.glide.Glide;
import com.example.entrega2.Chef;
import com.example.entrega2.Cliente;
import com.example.entrega2.MenuActivity;
import com.example.entrega2.R;
import com.example.entrega2.UtensiliosActivity;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class PerfilFragment extends Fragment {

    //MenuActivity menu=new MenuActivity();
    boolean chef;

    private PerfilViewModel perfilViewModel;
    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 9;
    public static final int REQUEST_CHECK_SETTINGS=10;
    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    public static final String PATH_CHEFS="chefs/";
    public static final String PATH_CLIENTS="clients/";
    public static final String PATH_IMAGES="images/";
    public static final String PATH_STORAGE="gs://entrega2-f3158.appspot.com/images/images";
    private StorageReference mStorage;

    boolean ubicacion=true;

    Switch simpleSwitch;
    TextView txtUser;
    TextView txtEmail;
    TextView txtEdad;
    TextView txtDir;
    TextView txtCel;
    ImageView imageView;
    Button btnUtensilios;

    public LocationRequest mLocationRequest;
    public LocationCallback mLocationCallback;
    private FusedLocationProviderClient mFusedLocationClient;
    Location locationReal;
    boolean disponible;


    
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //boolean chef = getArguments().getBoolean("chef");
        perfilViewModel =
                ViewModelProviders.of(this).get(PerfilViewModel.class);
        View root = inflater.inflate(R.layout.fragment_perfil, container, false);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(getContext());
        mLocationRequest = createLocationRequest();
        database= FirebaseDatabase.getInstance();
        mAuth=FirebaseAuth.getInstance();
        mStorage = FirebaseStorage.getInstance().getReference(PATH_IMAGES);
        txtUser= root.findViewById(R.id.txtUser);
        txtEmail= root.findViewById(R.id.txtEmail);
        txtCel= root.findViewById(R.id.txtCel);
        txtEdad=root.findViewById(R.id.txtEdad);
        txtDir=root.findViewById(R.id.txtDir);
        imageView=root.findViewById(R.id.imgUser);
        btnUtensilios=root.findViewById(R.id.btnUtensilios);
        btnUtensilios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getContext(), UtensiliosActivity.class);
                intent.putExtra("chef",chef);
                startActivity(intent);
            }
        });
        //Seters
        txtUser.setText(mAuth.getCurrentUser().getDisplayName());
        txtEmail.setText(mAuth.getCurrentUser().getEmail());

        MenuActivity menu= (MenuActivity) getActivity();
        chef=menu.getChef();
        final FirebaseUser user = mAuth.getCurrentUser();
        if(chef){
            myRef = database.getReference(PATH_CHEFS);
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    //DataSnapshot singleSnapshot = myRef.child(mAuth.getUid());
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        Log.i("NOENCUENTRA","NOENCUTRA");
                        if(user.getUid().equals(singleSnapshot.getKey())) {
                            Log.i("TRUE","TRUE");
                            Chef chef = singleSnapshot.getValue(Chef.class);
                            String age = String.valueOf(chef.getEdad());
                            String lugar = chef.getDireccion().getDir()+" | Lat:"+String.valueOf(chef.getDireccion().getLatitud())
                                    +" | Long:"+String.valueOf(chef.getDireccion().getLongitud());
                            String tele = String.valueOf(chef.getTelefono());
                            txtEdad.setText(age);
                            txtDir.setText(lugar);
                            txtCel.setText(tele);
                            StorageReference mImageRef =
                                    FirebaseStorage.getInstance().getReference("images/images/"+chef.getFoto());
                            mImageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                                @Override
                                public void onComplete(@NonNull Task<Uri> task) {
                                    if(task.isSuccessful())
                                    {
                                        Glide.with(getContext())
                                                .load(task.getResult())
                                                .apply(RequestOptions.circleCropTransform())
                                                .into(imageView);

                                    }
                                    else {
                                        Log.d("Firebase id",user.getUid());
                                    }
                                }
                            });
                        }
                    } }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.w("TAG", "error en la consulta", databaseError.toException()); }
            });
        }
        else{
            Log.i("FALSO","FALSO");
            myRef = database.getReference(PATH_CHEFS);
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    //DataSnapshot singleSnapshot = myRef.child(mAuth.getUid());
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        Log.i("NOENCUENTRA","NOENCUTRA");
                        if(user.getUid().equals(singleSnapshot.getKey())) {
                            Log.i("TRUE","TRUE");
                            Cliente cliente= singleSnapshot.getValue(Cliente.class);
                            String age = String.valueOf(cliente.getEdad());
                            String lugar = cliente.getDireccion().getDir()+" | Lat:"+String.valueOf(cliente.getDireccion().getLatitud())
                                    +" | Long:"+String.valueOf(cliente.getDireccion().getLongitud());
                            txtCel.setText(String.valueOf(cliente.getTelefono()));
                            txtEdad.setText(age);
                            txtDir.setText(lugar);
                            StorageReference mImageRef =
                                    FirebaseStorage.getInstance().getReference("images/images/"+cliente.getFoto());
                            mImageRef.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                                @Override
                                public void onComplete(@NonNull Task<Uri> task) {
                                    if(task.isSuccessful())
                                    {
                                        Glide.with(getContext())
                                                .load(task.getResult())
                                                .apply(RequestOptions.circleCropTransform())
                                                .into(imageView);

                                    }
                                    else {
                                        Log.d("Firebase id",user.getUid());
                                    }
                                }
                            });
                        }
                    } }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.w("TAG", "error en la consulta", databaseError.toException()); }
            });
        }

        //txtCel.setText(mAuth.getCurrentUser().getPhoneNumber());


        /*perfilViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/

        simpleSwitch=(Switch)root.findViewById(R.id.switch3);
        simpleSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        ubicacion=true;
                        myRef = database.getReference(PATH_CLIENTS);
                        myRef.child(mAuth.getUid()).child("disponible").setValue(true);
                        mLocationCallback=new LocationCallback(){
                            @Override
                            public void onLocationResult(LocationResult locationResult) {
                                Location location = locationResult.getLastLocation();
                                Log.i("logg","LOC: "+location);
                                if (location != null) {
                                    locationReal=location;
                                    mAuth= FirebaseAuth.getInstance();
                                    FirebaseUser currentUser=mAuth.getCurrentUser();
                                    myRef = database.getReference(PATH_CHEFS);
                                    myRef.child(mAuth.getUid()).child("ubicacionActual").setValue(new LatLng(locationReal.getLatitude(),locationReal.getLongitude()));
                                }
                            }
                        };
                        startLocationUpdates();
                        Log.i("DEVUELTA", String.valueOf(ubicacion));
                        disponible = true;
                    }
                    else{
                        ubicacion=false;
                        myRef = database.getReference(PATH_CHEFS);
                        myRef.child(mAuth.getUid()).child("disponible").setValue(false);
                        disponible=false;
                        simpleSwitch.setSplitTrack(false);
                        simpleSwitch.setChecked(false);
                    }
                }
                else{
                    Log.i("ENSERIO","WORK");
                    stopLocationUpdates();
                    myRef = database.getReference(PATH_CHEFS);
                    myRef.child(mAuth.getUid()).child("disponible").setValue(false);
                    disponible=false;
                    ubicacion=false;
                }
            }
        });
        return root;
    }

    private void askPermission() {
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an expanation to the user *asynchronouslyÂ  Â
                //Toast.makeText(this, "Se necesita el permiso para poder mostrar la ubicacion!", Toast.LENGTH_LONG).show();
            }
            // Request the permission.
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSIONS_REQUEST_LOCATION);
        }
        else ubicacion=true;
    }

    private LocationRequest createLocationRequest() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000); //tasa de refresco en milisegundos
        mLocationRequest.setFastestInterval(5000); //máxima tasa de refresco
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return mLocationRequest;
    }

    private void startLocationUpdates(){
        if(ContextCompat.checkSelfPermission(getContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
            //mFusedLocationClient=new FusedLocationProviderClient();
            mFusedLocationClient.requestLocationUpdates(mLocationRequest,
                    mLocationCallback, null);
            ubicacion=true;
        }else ubicacion=false;
    }

    private void stopLocationUpdates() {
        if (mFusedLocationClient != null)
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
    }
}


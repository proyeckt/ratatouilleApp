package com.example.entrega2.ui.disponibles;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.entrega2.Chef;
import com.example.entrega2.Cliente;
import com.example.entrega2.Direccion;
import com.example.entrega2.MenuActivity;
import com.example.entrega2.PerfilAgenoActivity;
import com.example.entrega2.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.osmdroid.util.GeoPoint;

import java.util.ArrayList;

public class DisponiblesFragment extends Fragment implements LocationListener {

    private DisponiblesViewModel disponiblesViewModel;
    ListView lista;
    boolean esChef;
    ArrayList<Chef> listachef;
    ArrayList<Cliente> listaCliente;
    ArrayList<String> listaNombres;
    ArrayList<String> listaDistancias;
    FirebaseDatabase database;
    DatabaseReference myRef;
    FusedLocationProviderClient client;
    LocationRequest mlocatioRequest;
    Location ubicacionActual;
    public static final String PATH_CHEFS = "chefs/";
    public static final String PATH_CLIENT = "clients/";
    LocationManager locationManager;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        disponiblesViewModel =
                ViewModelProviders.of(this).get(DisponiblesViewModel.class);
        View root = inflater.inflate(R.layout.fragment_disponibles, container, false);

        MenuActivity menu = (MenuActivity) getActivity();
        client= LocationServices.getFusedLocationProviderClient(getActivity());

        //locationManager = (LocationManager) this.getActivity().getSystemService(Context.LOCATION_SERVICE);

        //locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        while(ubicacionActual!=null){
        client.getLastLocation().addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location!=null){
                    System.out.println("ubicacion no nula");
                    ubicacionActual=location;
            }}
        });}
        esChef = menu.getChef();
        lista = root.findViewById(R.id.listaDisponibles);
        if (!esChef)
            loadUsers();
        else
            loadUsers2();

        //crearListas(listaNombres,listachef);
        //crearListas(listaDistancias,listachef);
        /*if(listaDistancias.isEmpty() || listaNombres.isEmpty())
            System.out.println("aca tambien es nulo");
        else {
            Adaptador adaptador = new Adaptador(this.getContext(), listaNombres, listaDistancias);
            lista.setAdapter(adaptador);
            lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    double latitud = listachef.get(position).getDireccion().getLatitud();
                    double longitud = listachef.get(position).getDireccion().getLongitud();
                    //hacer el intent al fragment home
                    //Intent intent
                }
            });
        }*/


        return root;
    }

    private void loadUsers2() {
        listaCliente = new ArrayList<>();
        listaNombres = new ArrayList<>();
        listaDistancias = new ArrayList<>();
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference(PATH_CLIENT);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int num = 0;
                if (dataSnapshot.exists()) {
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {

                        Cliente cliente = singleSnapshot.getValue(Cliente.class);
                        System.out.println("nombreChef de la clase: " + cliente.getNombre());
                        listaCliente.add(cliente);
                        listaNombres.add(cliente.getNombre() + cliente.getApellido());
                        System.out.println("nombre desde listaNombre: " + listaNombres.get(num));
                        String dire1 = String.valueOf(cliente.getDireccion().getLatitud());
                        String dire2 = String.valueOf(cliente.getDireccion().getLongitud());
                        String direccion = "Latitud: " + dire1 + " Longitud: " + dire2;
                        //direccion = distanciaAString(Ubicacionmia, ubicacionFuera)
                        listaDistancias.add(direccion);
                        System.out.println("direccion desde lista: " + listaDistancias.get(num));
                        num++;

                    }

                    if (!listaDistancias.isEmpty() && !listaNombres.isEmpty()) {
                        Adaptador adaptador = new Adaptador(getActivity(), listaNombres, listaDistancias);
                        lista.setAdapter(adaptador);
                        //System.out.println("cuantas veces paso por aca?");
                        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                double latitud = listaCliente.get(position).getDireccion().getLatitud();
                                double longitud = listaCliente.get(position).getDireccion().getLongitud();
                                System.out.println(longitud + " Espacio " + latitud);
                                Intent i = new Intent(getActivity(), PerfilAgenoActivity.class);
                                //i.putExtra("ubicacion",ubicacionActual);
                                i.putExtra("entidad",listaCliente.get(position));
                                i.putExtra("tipo","u");
                                startActivity(i);
                                //hacer el intent al fragment home
                                //Intent intent

                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                System.out.println("F");
            }
        });
    }


    public void loadUsers() {
        listachef = new ArrayList<>();
        listaNombres = new ArrayList<>();
        listaDistancias = new ArrayList<>();
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference(PATH_CHEFS);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int num = 0;
                if (dataSnapshot.exists()) {
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {

                        Chef chef = singleSnapshot.getValue(Chef.class);
                        if(!chef.isDisponible()){}
                        else {
                            System.out.println("nombreChef de la clase: " + chef.getNombre());
                            listachef.add(chef);

                            listaNombres.add(chef.getNombre() + chef.getApellido());
                            System.out.println("nombre desde listaNombre: " + listaNombres.get(num));
                            String dire1 = String.valueOf(chef.getDireccion().getLatitud());
                            String dire2 = String.valueOf(chef.getDireccion().getLongitud());
                            String direccion = "Latitud: " + dire1 + " Longitud: " + dire2;
                            //direccion = distanciaAString(Ubicacionmia, ubicacionFuera)
                            listaDistancias.add(direccion);
                            System.out.println("direccion desde lista: " + listaDistancias.get(num));
                            num++;
                        }
                    }

                    if (!listaDistancias.isEmpty() && !listaNombres.isEmpty()) {
                        //filtrar();
                        Adaptador adaptador = new Adaptador(getActivity(), listaNombres, listaDistancias);
                        lista.setAdapter(adaptador);
                        //System.out.println("cuantas veces paso por aca?");
                        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                double latitud = listachef.get(position).getDireccion().getLatitud();
                                double longitud = listachef.get(position).getDireccion().getLongitud();
                                System.out.println(longitud + " Espacio " + latitud);
                                Intent i = new Intent(getActivity(), PerfilAgenoActivity.class);
                                i.putExtra("latitud",ubicacionActual.getLatitude());
                                i.putExtra("longitud",ubicacionActual.getLongitude());
                                i.putExtra("entidad", listachef.get(position));
                                i.putExtra("tipo","C");
                                startActivity(i);
                                //buscarpor(nombre,distancia)
                                //hacer el intent al fragment home
                                //Intent intent
                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                System.out.println("F");
            }
        });
    }

    private void filtrar() {
        for (Chef chefsito:listachef){
            if (!chefsito.isDisponible() || 5>distance(ubicacionActual.getLatitude(),ubicacionActual.getLongitude(),chefsito.getDireccion().getLatitud(),chefsito.getDireccion().getLongitud())){
                listachef.remove(chefsito);
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        ubicacionActual = location;
        System.out.println("cambio de ubicacion");
        //crearMarcadorOrigen(u);
        //myMapController.animateTo(u);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    class Adaptador extends ArrayAdapter<String> {
        Context context;
        ArrayList<String> nombres;
        ArrayList<String> distancias;
        //String imagenes[];

        Adaptador(Context c, ArrayList<String> n, ArrayList<String> d) {
            super(c, R.layout.fila_disponibles, R.id.nombrePersonaFila, n);
            this.context = c;
            //this.imagenes=i;
            this.nombres = n;
            this.distancias = d;


        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View fila = layoutInflater.inflate(R.layout.fila_disponibles, parent, false);
            //ImageView imagen = fila.findViewById(R.id.foto);
            TextView nombre = fila.findViewById(R.id.nombrePersonaFila);
            TextView distancia = fila.findViewById(R.id.distancia);
            //imagen.setImageResource();
            nombre.setText(nombres.get(position));
            distancia.setText(distancias.get(position));
            return fila;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(locationManager!=null){
            locationManager.removeUpdates(this);
        }
    }

    public double distance(double lat1, double long1, double lat2, double long2) {
        double latDistance = Math.toRadians(lat1 - lat2);
        double lngDistance = Math.toRadians(long1 - long2);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double result = 6371 * c;
        return Math.round(result * 100.0) / 100.0;
    }
}

package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Register extends Activity {
    Button btnCliente;
    Button btnChef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);
        btnCliente=(Button) findViewById(R.id.btnClient);
        btnChef=(Button) findViewById(R.id.btnChef);
        btnCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(),RegisterClient.class);
                startActivity(intent);
            }
        });

        btnChef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(),RegisterChef.class);
                startActivity(intent);
            }
        });

    }
}

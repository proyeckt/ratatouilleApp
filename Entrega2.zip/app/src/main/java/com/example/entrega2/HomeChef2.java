package com.example.entrega2;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class HomeChef2 extends Activity {

    private FusedLocationProviderClient mFusedLocationClient;

    private Location locationReal;
    public static final double LatitudAeropuerto =4.698646;
    public static final double LongitudAeropuerto = -74.140963;

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 9;
    public static final int REQUEST_CHECK_SETTINGS=10;
    public static final String PATH_SOLICITUDES="solicitudes/";
    public static final String PATH_CHEFS="chefs/";


    //Limites Bogota
    public static final double lowerLeftLatitude = 4.147329;
    public static final double lowerLeftLongitude= -74.319839;
    public static final double upperRightLatitude= 4.878387;
    public static final double upperRigthLongitude= -73.988876;

    FirebaseAuth mAuth;

    ArrayList<Solicitud> solicitudes=new ArrayList<>();

    FirebaseDatabase database;
    DatabaseReference myRef;

    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_chef2);


        database= FirebaseDatabase.getInstance();

        list = (ListView) findViewById(R.id.listView);

        myRef = database.getReference(PATH_SOLICITUDES);
        //Deberia tener 2 addValueEventListener. Primero el de la ubicacion y luego el de solicitudes
        /*mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.getLastLocation().addOnSuccessListener(this, new
                OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            locationReal=location;
                            Log.i(" LOCATION ", "Longitud: " + location.getLongitude());
                            Log.i(" LOCATION ", "Latitud: " + location.getLatitude());
                        }
                    }
                });*/

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                    mAuth = FirebaseAuth.getInstance();
                    FirebaseUser currentUser = mAuth.getCurrentUser();
                    myRef = database.getReference(PATH_CHEFS);
                    myRef.child(mAuth.getUid());
                    Log.i("raro","hI");
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        Chef chf = singleSnapshot.getValue(Chef.class);
                        Log.i("entra",mAuth.getUid());
                    }
                    Log.i("OUT","OUT");

                Log.i("size:", String.valueOf(solicitudes.size()));
                    /*solicitudes.clear();
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        Solicitud soli = singleSnapshot.getValue(Solicitud.class);
                        double distancia = distance(locationReal.getLatitude(), locationReal.getLongitude(), soli.getDir_servicio().getLatitud(), soli.getDir_servicio().getLongitud());
                        System.out.println("Soli: " + soli.getNombre_cliente() + ":" + distancia);
                        if (distancia <= 5) {
                            Log.i("haa", soli.getDescripcion());
                            solicitudes.add(soli);
                        }
                    }*/
                    list.setAdapter(null);
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getBaseContext(),
                    android.R.layout.simple_list_item_1, valoresLista());
                    list.setAdapter(adapter);
        }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG", "error en la consulta", databaseError.toException());
            }
        });
    }

    public List<String> valoresLista(){
        List<String> lista=new ArrayList<>();
        for (Solicitud sol: solicitudes){
            String s=sol.getNombre_cliente()+ " - " +sol.getDir_servicio().getDir()+ " - "+ sol.getDescripcion();
            lista.add(s);
        }
        solicitudes.clear();
        return lista;
    }

    public double distance(double lat1, double long1, double lat2, double long2) {
        double latDistance = Math.toRadians(lat1 - lat2);
        double lngDistance = Math.toRadians(long1 - long2);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double result = 6371 * c;
        return Math.round(result*100.0)/100.0;
    }

}

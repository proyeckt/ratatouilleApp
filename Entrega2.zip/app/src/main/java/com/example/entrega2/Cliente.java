package com.example.entrega2;

import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.RequiresApi;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

import static java.time.LocalDate.now;

public class Cliente implements Parcelable {
    private String nombre;
    private String apellido;
    private String correo;
    private String password;
    private int edad;
    private String fecha_nacimiento;
    private String foto;
    private Direccion direccion;
    private ArrayList<String> utensilios;
    private long telefono;
    private double creditos;

    public long getTelefono() {
        return telefono;
    }

    public void setTelefono(long telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public ArrayList<String> getUtensilios() {
        return utensilios;
    }

    public void setUtensilios(ArrayList<String> utensilios) {
        this.utensilios = utensilios;
    }

    public Cliente(String nombre, String apellido, String correo, String password) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.password = password;
    }

    public Cliente() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.nombre);
        dest.writeString(this.apellido);
        dest.writeString(this.correo);
        dest.writeString(this.password);
    }

    private Cliente(Parcel in) {
        nombre = in.readString();
        apellido = in.readString();
        correo = in.readString();
        password = in.readString();

    }

    public static final Creator<Cliente> CREATOR = new Parcelable.Creator<Cliente>() {
        @Override
        public Cliente createFromParcel(Parcel source) {
            return new Cliente(source);
        }
        @Override
        public Cliente[] newArray(int size) {
            return new Cliente[size];
        }
    };


    public int getEdad(){
        return edad;
    }

    public void setEdad(int edad){
        this.edad=edad;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public int setAge(Date fecha_nac){
        LocalDate ahora = now();
        LocalDate fecha= convertToLocalDateViaInstant(fecha_nac);
        Period periodo = Period.between(fecha,ahora);
        return periodo.getYears();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
        return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public double getCreditos() {
        return creditos;
    }

    public void setCreditos(double creditos) {
        this.creditos = creditos;
    }
}


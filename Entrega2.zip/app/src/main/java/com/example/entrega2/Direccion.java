package com.example.entrega2;

public class Direccion {
    private String dir;
    private double latitud;
    private double longitud;

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public double getLatitud() {
        return latitud;
    }

    public void setLatitud(double latitud) {
        this.latitud = latitud;
    }

    public double getLongitud() {
        return longitud;
    }

    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }

    public Direccion(String dir, double latitud, double longitud) {
        this.dir = dir;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public Direccion() {
    }
}

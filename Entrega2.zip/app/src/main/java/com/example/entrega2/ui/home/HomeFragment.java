package com.example.entrega2.ui.home;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.entrega2.R;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

public class HomeFragment extends Fragment implements LocationListener {

    Button boton;
    private MapView myOpenMapView;
    private MapController myMapController;
    Marker actual;
    Location actu;

    private HomeViewModel homeViewModel;
    LocationManager locationManager;

    View root;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        root = inflater.inflate(R.layout.fragment_home, container, false);

        Context ctx = getContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

        //actu =
        GeoPoint ubicacionActual=new GeoPoint(4.6097100,-74.0817500);

        myOpenMapView =(MapView) root.findViewById(R.id.openmapview);
        myOpenMapView.setTileSource(TileSourceFactory.MAPNIK);

        myMapController=(MapController) myOpenMapView.getController();
        myMapController.setCenter(ubicacionActual);
        myMapController.setZoom(15);

        actual = new Marker(myOpenMapView);
        actual.setPosition(ubicacionActual);

        myOpenMapView.setMultiTouchControls(true);
        myOpenMapView.setBuiltInZoomControls(true);
        /*homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/

        locationManager = (LocationManager) this.getActivity().getSystemService(Context.LOCATION_SERVICE);

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onResume() {
        super.onResume();
        myOpenMapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        myOpenMapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(locationManager!=null){
            locationManager.removeUpdates(this);
        }
    }

    void crearMarcadorOrigen(GeoPoint g){
        Marker marcador= new Marker(myOpenMapView);
        marcador.setPosition(g);
        marcador.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM);
        marcador.setIcon(getResources().getDrawable(R.drawable.ic_action_name));
        myOpenMapView.getOverlays().clear();
        myOpenMapView.getOverlays().add(marcador);
        myOpenMapView.invalidate();

    }

    @Override
    public void onLocationChanged(Location location) {
        GeoPoint u = new GeoPoint(location.getLatitude(),location.getLongitude());
        crearMarcadorOrigen(u);
        myMapController.animateTo(u);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
package com.example.entrega2;

public class Solicitud {
    private String nombre_cliente;
    private Direccion dir_servicio;
    private String descripcion;

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public void setNombre_cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    public Direccion getDir_servicio() {
        return dir_servicio;
    }

    public void setDir_servicio(Direccion dir_servicio) {
        this.dir_servicio = dir_servicio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}

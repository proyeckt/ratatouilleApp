package com.example.entrega2;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeChef extends Activity {

    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 9;
    public static final int REQUEST_CHECK_SETTINGS=10;
    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    public static final String PATH_CHEFS="chefs/";

    boolean ubicacion=true;

    Switch simpleSwitch;
    Button btnSolicitudes;
    Button btnPerfil;
    Button btnButton;
    public LocationRequest mLocationRequest;
    public LocationCallback mLocationCallback;
    private FusedLocationProviderClient mFusedLocationClient;
    Location locationReal;
    boolean disponible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_chef);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mLocationRequest = createLocationRequest();
        database= FirebaseDatabase.getInstance();
        mAuth=FirebaseAuth.getInstance();
        myRef = database.getReference(PATH_CHEFS);
        //loadChefs();
        btnPerfil = findViewById(R.id.btnVerperfil);

        btnButton=findViewById(R.id.button);
        btnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(),MenuActivity.class);
                startActivity(intent);
            }
        });


        btnSolicitudes=(Button)findViewById(R.id.btnSolicitudes);

        simpleSwitch= (Switch) findViewById(R.id.switch1);

        /*
        simpleSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked){
                myRef.child(mAuth.getUid()).child("disponible").setValue(isChecked);
            }
        });
*/
        simpleSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    if (ContextCompat.checkSelfPermission(getBaseContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        ubicacion=true;
                        mLocationCallback=new LocationCallback(){
                            @Override
                            public void onLocationResult(LocationResult locationResult) {
                                Location location = locationResult.getLastLocation();
                                Log.i("logg","LOC: "+location);
                                if (location != null) {
                                    locationReal=location;
                                    mAuth=FirebaseAuth.getInstance();
                                    FirebaseUser currentUser=mAuth.getCurrentUser();
                                    myRef = database.getReference(PATH_CHEFS);
                                    myRef.child(mAuth.getUid()).child("ubicacionActual").setValue(new LatLng(locationReal.getLatitude(),locationReal.getLongitude()));
                                }
                            }
                        };
                        startLocationUpdates();
                        Log.i("DEVUELTA", String.valueOf(ubicacion));
                        disponible = true;
                    }
                    else{
                        ubicacion=false;
                        myRef.child(mAuth.getUid()).child("disponible").setValue(false);
                        disponible=false;
                        simpleSwitch.setSplitTrack(false);
                        simpleSwitch.setChecked(false);
                    }
                }
                else{
                    Log.i("ENSERIO","WORK");
                    stopLocationUpdates();
                    disponible=false;
                    ubicacion=false;
                }
            }
        });

        btnSolicitudes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(disponible) {
                    Intent intent = new Intent(getBaseContext(), HomeChef2.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(HomeChef.this, "Necesita estar disponible.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(),Perfil.class);
                intent.putExtra("tipo","C");
                startActivity(intent);
            }
        });
    }

    public void loadChefs() {
        myRef = database.getReference(PATH_CHEFS);

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                int i =1;
                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    System.out.println("unsuario numero "+i);
                    Chef chf= singleSnapshot.getValue(Chef.class);
                    Log.i("TAG", "Encontró usuario: " + chf.getNombre());
                    Log.i("TAG", "Encontró usuario: " + chf.getApellido());
                    Log.i("TAG", "Encontró usuario: " + chf.getCorreo());
                    Log.i("TAG", "Encontró usuario: " + chf.getPassword());
                    Log.i("TAG", "Encontró usuario: " + chf.getFoto());
                    Log.i("TAG", "Encontró usuario: " + chf.getFecha_nacimiento());
                    Log.i("TAG", "Encontró usuario: " + chf.getFormacion());
                    Log.i("TAG", "Encontró usuario: " + chf.getExperiencia());
                    i++;
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG", "error en la consulta", databaseError.toException());
            }
        });
    }

    private void askPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an expanation to the user *asynchronouslyÂ  Â
                //Toast.makeText(this, "Se necesita el permiso para poder mostrar la ubicacion!", Toast.LENGTH_LONG).show();
            }
            // Request the permission.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSIONS_REQUEST_LOCATION);
        }
        else ubicacion=true;
    }

    private LocationRequest createLocationRequest() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000); //tasa de refresco en milisegundos
        mLocationRequest.setFastestInterval(5000); //máxima tasa de refresco
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return mLocationRequest;
    }

    private void startLocationUpdates(){
        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
            //mFusedLocationClient=new FusedLocationProviderClient();
            mFusedLocationClient.requestLocationUpdates(mLocationRequest,
                    mLocationCallback, null);
            ubicacion=true;
        }else ubicacion=false;
    }

    private void stopLocationUpdates() {
        if (mFusedLocationClient != null)
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
    }
}

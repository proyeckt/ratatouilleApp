package com.example.entrega2;
import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class RegisterClient2 extends Activity {
    public static final int REQUEST_IMAGE_CAPTURE = 1;
    public static final int IMAGE_PICKER_REQUEST=2;

    public static final String PATH_CLIENTS="clients/";
    public static final String PATH_IMAGES="images/";
    FirebaseAuth mAuth;
    Uri url;
    Cliente cliente;
    FirebaseDatabase database;
    DatabaseReference myRef;
    private StorageReference mStorage;


    private static final String CERO = "0";
    private static final String BARRA = "/";

    //Calendario para obtener fecha & hora
    public final Calendar c = Calendar.getInstance();

    //Variables para obtener la fecha
    final int mes = c.get(Calendar.MONTH);
    final int dia = c.get(Calendar.DAY_OF_MONTH);
    final int anio = c.get(Calendar.YEAR);

    //Widgets
    Button btnRegister;
    ImageButton btnGaleria;
    ImageButton btnCamara;
    EditText etFecha;
    EditText txtDireccion;
    ImageButton ibObtenerFecha;

    Geocoder mGeocoder;


    //Limites Bogota
    public static final double lowerLeftLatitude = 4.147329;
    public static final double lowerLeftLongitude= -74.319839;
    public static final double upperRightLatitude= 4.878387;
    public static final double upperRigthLongitude= -73.988876;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_client2);

        Intent intent=getIntent();
        Bundle bundle =intent.getBundleExtra("bundle");
        cliente=(Cliente)bundle.get("cliente");

        database= FirebaseDatabase.getInstance();
        mStorage = FirebaseStorage.getInstance().getReference(PATH_IMAGES);

        etFecha = (EditText) findViewById(R.id.et_mostrar_fecha_picker);
        ibObtenerFecha = (ImageButton) findViewById(R.id.ib_obtener_fecha);
        btnRegister=(Button) findViewById(R.id.btnRegister);
        btnGaleria=(ImageButton) findViewById(R.id.btnGaleria);
        btnCamara=(ImageButton) findViewById(R.id.btnCamara);

        txtDireccion=(EditText) findViewById(R.id.txtDireccion);

        mGeocoder = new Geocoder(getBaseContext());

        ibObtenerFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obtenerFecha();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                if(cliente!=null){
                    LatLng nuevo=busquedaDireccion(txtDireccion.getText().toString());
                    Direccion dir=new Direccion(txtDireccion.getText().toString(),nuevo.latitude,nuevo.longitude);
                    cliente.setDireccion(dir);
                    StorageReference filePath = mStorage.child(PATH_IMAGES).child(url.getLastPathSegment());

                    filePath.putFile(url)
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    Log.i("work","Foto subida correctamente");
                                }
                            });
                    cliente.setFoto(url.getLastPathSegment());
                    Date date=new Date();
                    try {
                        cliente.setFecha_nacimiento(etFecha.getText().toString());
                        date=new SimpleDateFormat("dd/mm/yyyy").parse(etFecha.getText().toString());
                        int edad=cliente.setAge(date);
                        cliente.setEdad(edad);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    cliente.setCreditos(0);
                    registrarUsuario();
                }
            }
        });
        btnCamara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                askPermission();
                if (ContextCompat.checkSelfPermission(getBaseContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    takePicture();
                }
            }
        });

        btnGaleria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                askPermission2();
                if (ContextCompat.checkSelfPermission(getBaseContext(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    Intent pickImage = new Intent(Intent.ACTION_PICK);
                    pickImage.setType("image/*");
                    startActivityForResult(pickImage, IMAGE_PICKER_REQUEST);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_IMAGE_CAPTURE : {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    takePicture();
                }
            }
            break;
            case IMAGE_PICKER_REQUEST: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Acceso a almacenamiento!", Toast.LENGTH_LONG).show();
                    Intent pickImage = new Intent(Intent.ACTION_PICK);
                    pickImage.setType("image/*");
                    startActivityForResult(pickImage, IMAGE_PICKER_REQUEST);

                }
            }
            break;
        }
    }
    private void askPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                // Show an expanation to the user *asynchronouslyÂ  Â
                Toast.makeText(this, "Se necesita el permiso para poder mostrar la camara!", Toast.LENGTH_LONG).show();
            }
            // Request the permission.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_IMAGE_CAPTURE);
        }
    }

    private void askPermission2(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                // Show an expanation to the user *asynchronouslyÂ  Â
                Toast.makeText(this, "Se necesita el permiso para poder mostrar las imagenes de galeria!", Toast.LENGTH_LONG).show();
            }
            // Request the permission.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, IMAGE_PICKER_REQUEST);
        }
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode) {
            case IMAGE_PICKER_REQUEST: {
                if (resultCode == RESULT_OK) {
                    try {
                        final Uri imageUri = data.getData();
                        final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                        final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                        url=imageUri;
                        //image.setImageBitmap(selectedImage);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
            break;
            case REQUEST_IMAGE_CAPTURE:{
                if( resultCode == RESULT_OK){
                    Bundle extras = data.getExtras();
                    final Uri imageUri=data.getData();
                    url=imageUri;
                    Log.i("URRL:",url.toString());
                    Bitmap imageBitmap = (Bitmap) extras.get("data");
                    //image.setImageBitmap(imageBitmap);
                }
            }
            break;
        }
    }
    private void takePicture() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    private void registrarUsuario(){
        if(cliente==null)
            return;
        String email = cliente.getCorreo();
        String password = cliente.getPassword();
        mAuth= FirebaseAuth.getInstance();
        Log.i("correo",email);
        mAuth.createUserWithEmailAndPassword(email, password) .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Log.d("TAG", "createUserWithEmail:onComplete:" + task.isSuccessful());
                    FirebaseUser user = mAuth.getCurrentUser();
                    if(user!=null){ //Update user Info
                        UserProfileChangeRequest.Builder upcrb = new UserProfileChangeRequest.Builder();
                        String display=cliente.getNombre()+" "+cliente.getApellido();
                        upcrb.setDisplayName(display);
                        upcrb.setPhotoUri(Uri.parse(url.getLastPathSegment()));//fake uri, use Firebase Storage user.updateProfile(upcrb.build());
                        user.updateProfile(upcrb.build());
                        updateUI(user);
                    }
                }
                if (!task.isSuccessful()) {
                    Toast.makeText(RegisterClient2.this, /*R.string.auth_failed+task.getException().toString()*/"Fallo en el sistema, intente de nuevo", Toast.LENGTH_SHORT).show();
                    Log.e("TAG", task.getException().getMessage()); }
            } });

    }

    private void updateUI(FirebaseUser currentUser) {
        if (currentUser != null) {
            myRef=database.getReference(PATH_CLIENTS+currentUser.getUid());
            myRef.setValue(cliente);
            Intent intent = new Intent(getBaseContext(), WelcomeClient.class);
            intent.putExtra("name",currentUser.getDisplayName());
            startActivity(intent);
        }
    }

    private void obtenerFecha(){
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                //Esta variable lo que realiza es aumentar en uno el mes ya que comienza desde 0 = enero
                final int mesActual = month + 1;
                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                //Muestro la fecha con el formato deseado
                etFecha.setText(diaFormateado + BARRA + mesFormateado + BARRA + year);


            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
            /**
             *También puede cargar los valores que usted desee
             */
        },anio, mes, dia);
        //Muestro el widget
        recogerFecha.show();
    }

    public LatLng busquedaDireccion(String direccion){
        LatLng position=new LatLng(0,0);
        try {
            List<Address> addresses = mGeocoder.getFromLocationName(direccion, 5,lowerLeftLatitude, lowerLeftLongitude, upperRightLatitude, upperRigthLongitude);
            if (addresses != null && !addresses.isEmpty()) {
                Address addressResult = addresses.get(0);
                position = new LatLng(addressResult.getLatitude(), addressResult.getLongitude());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return position;
    }
}
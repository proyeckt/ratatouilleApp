package com.example.entrega2.ui.disponibles;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DisponiblesViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public DisponiblesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is share fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
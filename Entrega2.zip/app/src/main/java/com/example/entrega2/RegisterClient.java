package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterClient extends Activity {
    EditText txtNombre;
    EditText txtApellido;
    EditText txtCorreo;
    EditText txtPassword;
    EditText txtTelefono;
    Button btnNext;
    Button btnLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_client);

        txtNombre=(EditText) findViewById(R.id.et_nombre);
        txtApellido=(EditText) findViewById(R.id.et_apellido);
        txtCorreo=(EditText) findViewById(R.id.et_correo);
        txtPassword=(EditText) findViewById(R.id.et_contrasena);
        txtTelefono=(EditText) findViewById(R.id.et_telefono);

        btnNext=(Button)findViewById(R.id.btnNext);
        btnLogin=(Button)findViewById(R.id.btn_ir_inicioSesion);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(),Login.class);
                startActivity(intent);
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txtNombre.getText().toString().isEmpty() && !txtApellido.getText().toString().isEmpty() && !txtCorreo.getText().toString().isEmpty() && !txtPassword.getText().toString().isEmpty() && !txtTelefono.getText().toString().isEmpty()){
                Cliente cliente=new Cliente(txtNombre.getText().toString(),txtApellido.getText().toString(),txtCorreo.getText().toString(),txtPassword.getText().toString());
                long d= new Long(Long.parseLong(txtTelefono.getText().toString()));
                //Log.i("hi",Long.getLong(txtTelefono.getText().toString()).toString());
                cliente.setTelefono(d);
                Intent intent=new Intent(getBaseContext(),RegisterClient2.class);
                Bundle bundle=new Bundle();
                bundle.putParcelable("cliente",cliente);
                intent.putExtra("bundle", bundle);
                startActivity(intent);
                }
            }
        });
    }
}

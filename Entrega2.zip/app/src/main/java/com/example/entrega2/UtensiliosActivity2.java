package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UtensiliosActivity2 extends Activity {
    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    public static final String PATH_CHEFSXUTENSILIOS="chefsxutensilios/";
    public static final String PATH_CLIENTSXUTENSILIOS="clientsxutensilios/";

    boolean chef;
    EditText txtAgregar;
    Button btnAgregar;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.utensilios_activity2);
        mAuth= FirebaseAuth.getInstance();
        database= FirebaseDatabase.getInstance();
        Intent intent=getIntent();
        chef=intent.getBooleanExtra("chef",false);
        txtAgregar=(EditText) findViewById(R.id.txtAgregar);
        btnAgregar=(Button)findViewById(R.id.btnUtensilios);
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txtAgregar.getText().toString().isEmpty()){
                    // Crear nuevo chefxutensilio
                    DatabaseReference pathReference;
                    if(chef)
                        pathReference = myRef = database.getReference(PATH_CHEFSXUTENSILIOS);//FirebaseDatabase.getInstance().getReference().child(PATH_CLIENTSXUTENSILIOS)
                    else pathReference = myRef = database.getReference(PATH_CLIENTSXUTENSILIOS);
                    DatabaseReference push = pathReference.push();
                    push.child("user").setValue(mAuth.getCurrentUser().getUid());
                    push.child("utensilio").setValue(txtAgregar.getText().toString());
                    Intent intent=new Intent(getBaseContext(),UtensiliosActivity.class);
                    startActivity(intent);
                }
            }
        });

    }
}

package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.fragment.app.FragmentManager;

import com.example.entrega2.ui.calificaciones.CalificacionesFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CalificacionesActivity extends Activity {
    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    public static final String PATH_CALIFICACIONES="calificaciones/";
    RatingBar ratingBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.calificaciones_activity);

        Intent intent=getIntent();
        final String uidChef=intent.getStringExtra("uid");
        ratingBar=(RatingBar) findViewById(R.id.ratingBar);
        database= FirebaseDatabase.getInstance();
        myRef=database.getReference();
        mAuth=FirebaseAuth.getInstance();

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                Calificacion cali=new Calificacion();
                int d=(int)ratingBar.getRating();
                cali.setNota(d);
                cali.setCliente(mAuth.getUid());
                cali.setChef(uidChef);
                DatabaseReference pathReference = database.getReference(PATH_CALIFICACIONES);
                pathReference.push().setValue(cali);
                Toast.makeText(getBaseContext(),"Calificacion actualizada",Toast.LENGTH_LONG).show();
                Intent returnIntent = new Intent();
                setResult(Activity.RESULT_CANCELED,returnIntent);
                finish();
            }
        });
    }
}

package com.example.entrega2;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class WelcomeChef extends Activity {

    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 9;
    public static final int REQUEST_CHECK_SETTINGS=10;
    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    public static final String PATH_CHEFS="chefs/";

    boolean ubicacion=true;
    boolean activarUbicacion=false;
    public LocationRequest mLocationRequest;
    public LocationCallback mLocationCallback;
    private FusedLocationProviderClient mFusedLocationClient;
    Location locationReal;

    TextView txt;
    Button btnPermiso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_activity);
        Intent intent=getIntent();
        String name=intent.getStringExtra("name");
        txt=(TextView) findViewById(R.id.txtWelcome);
        String strings="Bienvenido "+name;
        txt.setText(strings.toUpperCase());
        btnPermiso=(Button) findViewById(R.id.btnPermiso);
        btnPermiso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                askPermission();
                if(ubicacion){
                    if(activarUbicacion) {
                        Intent intent2 = new Intent(getBaseContext(), MenuActivity.class);
                        intent2.putExtra("chef",true);
                        startActivity(intent2);
                    }
                    else enableLocation();
                }
            }
        });
        //Esperar 2 segundos
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                //que hacer despues de 2 segundos
                locationProcess();
                if(ubicacion) {
                    if(activarUbicacion) {
                        Intent intent2 = new Intent(getBaseContext(), MenuActivity.class);
                        intent2.putExtra("chef",true);
                        startActivity(intent2);
                    }
                    else enableLocation();
                }
                else btnPermiso.setVisibility(View.VISIBLE);
            }
        }, 3000);
    }

    void locationProcess(){
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mLocationRequest = createLocationRequest();
        askPermission();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            ubicacion=true;
            if(activarUbicacion){
                Intent intent2 = new Intent(getBaseContext(), MenuActivity.class);
                intent2.putExtra("chef",true);
                startActivity(intent2);
            }
            else enableLocation();
        }
        else{
            ubicacion=false;
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    ubicacion=true;
                    if(activarUbicacion){
                        Intent intent2 = new Intent(getBaseContext(), MenuActivity.class);
                        intent2.putExtra("chef",true);
                        startActivity(intent2);
                    }
                    else enableLocation();
                } else {
                    /*Log.i("ENSERIO","WORK");
                    myRef.child(mAuth.getUid()).child("disponible").setValue(false);
                    disponible=false;*/
                    ubicacion=false;
                    //askPermission();
                }
            }
            break;

        }
    }
    private void askPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an expanation to the user *asynchronouslyÂ  Â
                //Toast.makeText(this, "Se necesita el permiso para poder mostrar la ubicacion!", Toast.LENGTH_LONG).show();
            }
            // Request the permission.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSIONS_REQUEST_LOCATION);
        }
        else ubicacion=true;
    }


    private LocationRequest createLocationRequest() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000); //tasa de refresco en milisegundos
        mLocationRequest.setFastestInterval(5000); //máxima tasa de refresco
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return mLocationRequest;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mFusedLocationClient!=null && mLocationCallback!=null)
            startLocationUpdates();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mFusedLocationClient!=null && mLocationCallback!=null) {
            stopLocationUpdates();
        }
    }

    private void startLocationUpdates(){
        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED){
            //mFusedLocationClient=new FusedLocationProviderClient();
            mFusedLocationClient.requestLocationUpdates(mLocationRequest,
                    mLocationCallback, null);
            ubicacion=true;
        }else ubicacion=false;
    }

    private void stopLocationUpdates() {
        if (mFusedLocationClient != null)
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            // Check for the integer request code originally supplied to startResolutionForResult().
            case REQUEST_CHECK_SETTINGS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        activarUbicacion=true;
                        if(ubicacion){
                            Intent intent2 = new Intent(getBaseContext(), MenuActivity.class);
                            intent2.putExtra("chef",true);
                            startActivity(intent2);
                        }
                        Log.i("the gps back on","HA");
                        break;
                    case Activity.RESULT_CANCELED:
                        activarUbicacion=false;
                        Log.i("gps back off","OMG");
                        enableLocation();
                        break;
                }
                break;
        }
    }

    void enableLocation(){
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest);
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                //startLocationUpdates();
                ubicacion=true;
                activarUbicacion=true;
                Intent intent2 = new Intent(getBaseContext(), MenuActivity.class);
                intent2.putExtra("chef",true);
                startActivity(intent2);
                //Todas las condiciones para recibir localizaciones
            }
        });

        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                int statusCode = ((ApiException) e).getStatusCode();
                switch (statusCode) {
                    case CommonStatusCodes.RESOLUTION_REQUIRED:
// Location settings are not satisfied, but this can be fixed by showing the user a dialog.
                        try {// Show the dialog by calling startResolutionForResult(), and check the result in onActivityResult().
                            ResolvableApiException resolvable = (ResolvableApiException) e;
                            resolvable.startResolutionForResult(WelcomeChef.this,
                                    REQUEST_CHECK_SETTINGS);
                        } catch (IntentSender.SendIntentException sendEx) {
// Ignore the error.
                        } break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
// Location settings are not satisfied. No way to fix the settings so we won't show the dialog.
                        break;
                }
            }
        });
    }
}

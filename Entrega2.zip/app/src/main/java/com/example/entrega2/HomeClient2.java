package com.example.entrega2;

import android.app.Activity;
import android.os.Bundle;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;


public class HomeClient2 extends Activity {
    private MapView myOpenMapView;
    private MapController myMapController;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_client2);

        GeoPoint madrid=new GeoPoint(40.416775,-3.70379);
        myOpenMapView =(MapView) findViewById(R.id.openmapview);
        myOpenMapView.setBuiltInZoomControls(true);
        myMapController=(MapController) myOpenMapView.getController();
        Configuration.getInstance().setUserAgentValue(getPackageName());
        myOpenMapView.setTileSource(TileSourceFactory.MAPNIK);
        myMapController.setCenter(madrid);
        myMapController.setZoom(6);
        myOpenMapView.setMultiTouchControls(true);
    }

}

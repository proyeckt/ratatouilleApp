package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeClient extends Activity {
    FirebaseDatabase database;
    DatabaseReference myRef;

    Button btnDisponibles, btnPerfil;
    //String nombreCompleto, edad, direccion;
    public static final String PATH_CLIENTS="clients/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_client);
        database= FirebaseDatabase.getInstance();
        //loadClients();
        btnDisponibles=(Button)findViewById(R.id.btnDisponibles);
        btnPerfil = findViewById(R.id.btnPerfil);
        database = FirebaseDatabase.getInstance();
        btnDisponibles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(), HomeClient2.class);
                startActivity(intent);
            }
        });

        btnPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getBaseContext(),Perfil.class);
                i.putExtra("tipo","U");
                startActivity(i);
            }
        });
    }

    public void loadClients() {
        myRef = database.getReference(PATH_CLIENTS);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    Cliente clt= singleSnapshot.getValue(Cliente.class);
                    Log.i("TAG", "Encontró usuario: " + clt.getNombre());
                    Log.i("TAG", "Encontró usuario: " + clt.getApellido());
                    Log.i("TAG", "Encontró usuario: " + clt.getCorreo());
                    Log.i("TAG", "Encontró usuario: " + clt.getPassword());
                    Log.i("TAG", "Encontró usuario: " + clt.getFoto());
                    Log.i("TAG", "Encontró usuario: " + clt.getFecha_nacimiento());
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG", "error en la consulta", databaseError.toException());
            }
        });
    }


}

package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

public class RegisterChef extends Activity {
    EditText txtNombre;
    EditText txtApellido;
    EditText txtCorreo;
    EditText txtPassword;
    EditText txtTelefono;
    Button btnNext;
    Button btnLogin;
    Geocoder mGeocoder;

    //Limites Bogota
    public static final double lowerLeftLatitude = 4.147329;
    public static final double lowerLeftLongitude= -74.319839;
    public static final double upperRightLatitude= 4.878387;
    public static final double upperRigthLongitude= -73.988876;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_chef);

        txtNombre=(EditText) findViewById(R.id.et_nombre);
        txtApellido=(EditText) findViewById(R.id.et_apellido);
        txtCorreo=(EditText) findViewById(R.id.et_correo);
        txtPassword=(EditText) findViewById(R.id.et_contrasena);
        txtTelefono=(EditText) findViewById(R.id.et_telefono);

        btnNext=(Button)findViewById(R.id.btnNext);
        btnLogin=(Button)findViewById(R.id.btn_ir_inicioSesion);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(),Login.class);
                startActivity(intent);
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txtNombre.getText().toString().isEmpty() && !txtApellido.getText().toString().isEmpty() && !txtCorreo.getText().toString().isEmpty() && !txtPassword.getText().toString().isEmpty() && !txtTelefono.getText().toString().isEmpty()){
                    Chef chef=new Chef(txtNombre.getText().toString(),txtApellido.getText().toString(),txtCorreo.getText().toString(),txtPassword.getText().toString());
                    //System.out.println("hola"+Long.getLong());
                    long d= new Long(Long.parseLong(txtTelefono.getText().toString()));
                    //Log.i("hi",Long.getLong(txtTelefono.getText().toString()).toString());
                    chef.setTelefono(d);
                    Intent intent=new Intent(getBaseContext(),RegisterChef2.class);
                    Bundle bundle=new Bundle();
                    bundle.putParcelable("chef",chef);
                    intent.putExtra("bundle", bundle);
                    startActivity(intent);
                }
            }
        });
    }


}

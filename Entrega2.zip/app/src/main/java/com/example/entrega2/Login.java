package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends Activity {
    FirebaseDatabase database;
    DatabaseReference myRef;
    private FirebaseAuth mAuth;
    EditText txtUser;
    EditText txtPassword;
    Button btnLogin;
    Button btnRegister;


    public static final String PATH_CLIENTS="clients/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        txtUser=(EditText)findViewById(R.id.et_correo);
        txtPassword=(EditText)findViewById(R.id.et_contrasena);
        btnLogin=(Button)findViewById(R.id.btnLogin);
        btnRegister=(Button)findViewById(R.id.btnRegister);

        database= FirebaseDatabase.getInstance();
        mAuth= FirebaseAuth.getInstance();
        //mAuth.signOut();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signInUser(txtUser.getText().toString(),txtPassword.getText().toString());
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(),Register.class);
                startActivity(intent);
            }
        });
    }

    /*@Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }*/

    private void updateUI(FirebaseUser currentUser){
        if(currentUser!=null){
            //Verificar el tipo de usuario
            DatabaseReference myRef = database.getReference(PATH_CLIENTS);
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        if(FirebaseAuth.getInstance().getCurrentUser().getUid().equals(singleSnapshot.getKey())){
                            Log.i("cliente","CLIENTE!!");
                            Intent intent = new Intent(getBaseContext(), WelcomeClient.class);
                            intent.putExtra("name",FirebaseAuth.getInstance().getCurrentUser().getDisplayName());
                            startActivity(intent);
                            finish();
                            return;
                        }
                    }
                    Log.i("chef","CHEF!!");
                    Intent intent = new Intent(getBaseContext(), WelcomeChef.class);
                    intent.putExtra("name",FirebaseAuth.getInstance().getCurrentUser().getDisplayName());
                    startActivity(intent);
                    finish();
                    return;
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.w("TAG", "error en la consulta", databaseError.toException());
                }
            });
        } else {
            txtUser.setText("");
            txtPassword.setText("");
        }
    }


    private boolean validateForm() {
        boolean valid = true;
        String email = txtUser.getText().toString();
        if (TextUtils.isEmpty(email)) {
            txtUser.setError("Required.");
            valid = false;
        } else {
            if(!isEmailValid(email))
                txtUser.setError("Bad Format.");
            else txtUser.setError(null);
        }
        String password = txtPassword.getText().toString();
        if (TextUtils.isEmpty(password)) {
            txtPassword.setError("Required.");
            valid = false;
        } else txtPassword.setError(null);
        return valid;
    }

    private boolean isEmailValid(String email) {
        if (!email.contains("@") ||
                !email.contains(".") ||
                email.length() < 5)
            return false;
        return true;
    }

    private void signInUser(String email, String password) {
        if (validateForm()) {
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI
                                Log.d("TAG", "signInWithEmail:success");

                                FirebaseUser user = mAuth.getCurrentUser();
                                updateUI(user);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w("TAG", "signInWithEmail:failure", task.getException());
                                Toast.makeText(Login.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();
                                updateUI(null);
                            }
                        }
                    });
        }
    }
}

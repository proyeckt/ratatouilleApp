package com.example.entrega2.ui.calificaciones;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.entrega2.Calificacion;
import com.example.entrega2.CalificacionesActivity;
import com.example.entrega2.Chef;
import com.example.entrega2.Cliente;
import com.example.entrega2.MenuActivity;
import com.example.entrega2.R;
import com.example.entrega2.Solicitud;
import com.example.entrega2.UserxUtensilio;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CalificacionesFragment extends Fragment {

    private CalificacionesViewModel calificacionesViewModel;
    public MenuActivity menu=new MenuActivity();
    public boolean chef;
    public static final String PATH_CALIFICACIONES="calificaciones/";
    List<String> listilla=new ArrayList<>();

    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    ArrayList<Calificacion> calificaciones=new ArrayList<>();
    ListView list;
    public static final String PATH_CHEFS="chefs/";
    public static final String PATH_CLIENTS="clients/";


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        calificacionesViewModel =
                ViewModelProviders.of(this).get(CalificacionesViewModel.class);
        View root = inflater.inflate(R.layout.fragment_calificaciones, container, false);
        list = (ListView) root.findViewById(R.id.listCalificaciones);


        MenuActivity menu= (MenuActivity) getActivity();
        chef=menu.getChef();
        database= FirebaseDatabase.getInstance();
        myRef=database.getReference();
        mAuth=FirebaseAuth.getInstance();


        myRef=database.getReference(PATH_CALIFICACIONES);
        final FirebaseUser user = mAuth.getCurrentUser();
        myRef = database.getReference(PATH_CALIFICACIONES);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    Calificacion cali= singleSnapshot.getValue(Calificacion.class);
                    String uid;
                    if(chef)
                        uid=cali.getChef();
                    else uid=cali.getCliente();
                    if(uid.equals(user.getUid())){
                        Log.i("CALI",String.valueOf(cali.getNota()));
                        calificaciones.add(cali);
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG", "error en la consulta", databaseError.toException());
            }
        });
        if(chef){
            Log.i("GOD","THINGS");

        }
        else {
            Log.i("JUST","KIDDING");
        }
        listilla=valoresLista();
        Log.i("FF",String.valueOf(listilla.size()));
        list.setAdapter(null);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, listilla);
        list.setAdapter(adapter);
        //SE DEBE LLAMAR A LA ACTIVIDAD Y PASARLE EL UID DEL CHEF -> AQUI ESTA QUEMADO (VA EN PAGOS)
        Intent intent=new Intent(getContext(), CalificacionesActivity.class);
        intent.putExtra("uid","TFZIabA77LgeeK7EEUKQFgcaoIp2");
        startActivityForResult(intent, 1);
        return root;

    }

    public List<String> valoresLista(){
        database= FirebaseDatabase.getInstance();
        myRef=database.getReference();
        final List<String> lista=new ArrayList<>();
        final String user=FirebaseAuth.getInstance().getCurrentUser().getDisplayName();
        for (final Calificacion cali: calificaciones){
            final String uid;
            if(chef) {
                myRef = database.getReference(PATH_CLIENTS);
                uid=cali.getCliente();
            }
            else {
                myRef=database.getReference(PATH_CHEFS);
                uid=cali.getChef();
            }
            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    //DataSnapshot singleSnapshot = myRef.child(mAuth.getUid());
                    Log.i("EMPY",String.valueOf(dataSnapshot.getChildrenCount()));
                    for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                        //va.hashCode();
                        ///UserxUtensilio value=new UserxUtensilio();
                        //value.getClass().cast(va);
                        Log.i("KE",singleSnapshot.getKey().toString());
                        if (uid.equals(singleSnapshot.getKey())) {
                            Log.i("TRUE", "TRUE");
                            String nombre;
                            Cliente clt;
                            Chef ch;
                            String s;
                            if (chef) {
                                clt = singleSnapshot.getValue(Cliente.class);
                                nombre=clt.getNombre()+" "+clt.getApellido();
                                s=nombre+ " - " +user + " - "+ cali.getNota();

                            }
                            else {
                                ch = singleSnapshot.getValue(Chef.class);
                                nombre=ch.getNombre()+" "+ch.getApellido();
                                s= user+ " - " +nombre+ " - "+ cali.getNota();
                            }
                            lista.add(s);
                            Log.i("TAMLISTA",String.valueOf(lista.size()));
                        }
                            //Toast.makeText(Perfil.this, name + ":" + age, Toast.LENGTH_SHORT).show();
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.w("TAG", "error en la consulta", databaseError.toException()); }
            });
        }
        Log.i("TAMLISTA",String.valueOf(lista.size()));
        return lista;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            if(resultCode == Activity.RESULT_OK){
                //Haces lo que necesites con la data, en este caso asignas los vales a los EditText

            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Aqui escribes el codigo para cuando decidas no devolver data
            }
        }
    }
}
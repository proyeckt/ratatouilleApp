package com.example.entrega2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;

public class UtensiliosActivity extends Activity {
    boolean chef;
    ArrayList<String> utensilios=new ArrayList<>();
    ArrayAdapter<String> comboAdapter;
    Spinner spinner;
    Button btnEliminar;
    Button btnAgregar;

    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    public static final String PATH_CHEFSXUTENSILIOS="chefsxutensilios/";
    public static final String PATH_CLIENTSXUTENSILIOS="clientsxutensilios/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.utensilios_activity);
        Intent intent=getIntent();
        chef=intent.getBooleanExtra("chef",false);
        spinner=findViewById(R.id.spinner);
        //utensilios.add("Agregar Nuevo");
        llenarUtensilios();
        mAuth=FirebaseAuth.getInstance();
        database=FirebaseDatabase.getInstance();
        myRef= database.getReference();

        btnAgregar=findViewById(R.id.btnAgregar);
        btnEliminar=findViewById(R.id.btnEliminar);
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getBaseContext(),UtensiliosActivity2.class);
                intent.putExtra("chef",chef);
                startActivity(intent);
            }
        });
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String remover=(String)spinner.getSelectedItem();
                utensilios.remove(remover);
                mAuth=FirebaseAuth.getInstance();
                database=FirebaseDatabase.getInstance();
                myRef= database.getReference();
                if(chef)
                    myRef = database.getReference(PATH_CHEFSXUTENSILIOS);
                else myRef = database.getReference(PATH_CLIENTSXUTENSILIOS);
                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //DataSnapshot singleSnapshot = myRef.child(mAuth.getUid());
                        for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                            UserxUtensilio value= singleSnapshot.getValue(UserxUtensilio.class);
                            //va.hashCode();
                            ///UserxUtensilio value=new UserxUtensilio();
                            //value.getClass().cast(va);
                            if(spinner.getSelectedItem().equals(value.getUtensilio())) {
                                Log.i("TRUE","TRUE");
                                myRef=myRef.child(singleSnapshot.getKey());
                                myRef.removeValue();
                                //utensilios.add(value.getUtensilio());
                                //Toast.makeText(Perfil.this, name + ":" + age, Toast.LENGTH_SHORT).show();
                            }
                        } }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.w("TAG", "error en la consulta", databaseError.toException()); }
                });
                comboAdapter = new ArrayAdapter<>(getBaseContext(),android.R.layout.simple_spinner_item, utensilios);
                comboAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(comboAdapter);
            }
        });
        comboAdapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, utensilios);
        comboAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(comboAdapter);
        /*spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String nivel = (String) spinner.getSelectedItem();
                Toast.makeText(getBaseContext(), "El item seleccionado es: "+
                                spinner.getSelectedItemId()+" "+nivel,
                        Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });*/
    }

    public void llenarUtensilios(){
        mAuth=FirebaseAuth.getInstance();
        final FirebaseUser user =mAuth.getCurrentUser();
        database=FirebaseDatabase.getInstance();
        boolean prueba=true;
        if(chef)
            myRef = database.getReference(PATH_CHEFSXUTENSILIOS);
        else myRef = database.getReference(PATH_CLIENTSXUTENSILIOS);
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //DataSnapshot singleSnapshot = myRef.child(mAuth.getUid());
                for (DataSnapshot singleSnapshot : dataSnapshot.getChildren()) {
                    UserxUtensilio value= singleSnapshot.getValue(UserxUtensilio.class);
                    //va.hashCode();
                    ///UserxUtensilio value=new UserxUtensilio();
                    //value.getClass().cast(va);
                    if(user.getUid().equals(value.getUser())) {
                        Log.i("TRUE","TRUE");
                        utensilios.add(value.getUtensilio());
                        //Toast.makeText(Perfil.this, name + ":" + age, Toast.LENGTH_SHORT).show();
                    }
                } }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("TAG", "error en la consulta", databaseError.toException()); }
        });
    }
}

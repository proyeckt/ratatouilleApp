package com.example.entrega2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PerfilAgenoActivity extends AppCompatActivity {

    TextView nombre,nome, correo, distancia, telefono,edad;
    Button confirmar, ubicar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_ageno);

        nombre = findViewById(R.id.txtUser);
        nome = findViewById(R.id.txtName1);
        correo=findViewById(R.id.txtEmail);
        distancia = findViewById(R.id.txtDir);
        telefono=findViewById(R.id.txtCel);
        edad=findViewById(R.id.txtEdad);

        Intent i = getIntent();
        if (i.getStringExtra("tipo")=="C"){
            cargarChef();
        }
        else
            cargarCliente();
    }

    private void cargarChef() {
        Chef c = getIntent().getParcelableExtra("entidad");
        nombre.setText(c.getNombre()+" "+c.getApellido());
        nome.setText(c.getNombre()+" "+c.getApellido());
        correo.setText(c.getCorreo());
        double lon = getIntent().getDoubleExtra("longitud",0);
        double lat=getIntent().getDoubleExtra("latitud",0);
        double longi = c.getDireccion().getLongitud();
        double lati = c.getDireccion().getLatitud();
        distancia.setText(String.valueOf(distance(lat,lon,lati,longi)));
        telefono.setText(String.valueOf(c.getTelefono()));
        edad.setText(String.valueOf(c.getEdad()));


    }

    private void cargarCliente() {
        Cliente c = getIntent().getParcelableExtra("entidad");
        nombre.setText(c.getNombre()+" "+c.getApellido());
        nome.setText(c.getNombre()+" "+c.getApellido());
        correo.setText(c.getCorreo());
        double lon = getIntent().getDoubleExtra("longitud",0);
        double lat=getIntent().getDoubleExtra("latitud",0);
        double longi = c.getDireccion().getLongitud();
        double lati = c.getDireccion().getLatitud();
        distancia.setText(String.valueOf(distance(lat,lon,lati,longi)));
        telefono.setText(String.valueOf(c.getTelefono()));
        edad.setText(String.valueOf(c.getEdad()));

    }
    public double distance(double lat1, double long1, double lat2, double long2) {
        double latDistance = Math.toRadians(lat1 - lat2);
        double lngDistance = Math.toRadians(long1 - long2);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double result = 6371 * c;
        return Math.round(result * 100.0) / 100.0;
    }
}
